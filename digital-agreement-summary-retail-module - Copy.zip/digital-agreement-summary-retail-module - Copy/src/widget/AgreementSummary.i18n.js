import {defineMessages} from 'react-intl';


export default defineMessages({
    agreementSummaryTitle: {
        id: 'agreementSummaryTitle',
        defaultMessage: 'RESUMEN CONTRATARIAL'
    },
    hideTax: {
        id: 'hideTax',
        defaultMessage: 'Ocultar Impuesto'
    },
    showTax: {
        id: 'showTax',
        defaultMessage: 'Mostrar Impuesto'
    },
    totalSubscriptions: {
        id: 'totalSubscriptions',
        defaultMessage: 'Total de subscripciones'
    },
    services: {
        id: 'services',
        defaultMessage: 'Servicios'
    },
    devices: {
        id: 'devices',
        defaultMessage: 'Dispositivos'
    },
    installments: {
        id: 'installments',
        defaultMessage: 'Instalaciones'
    },
    fullPrice: {
        id: 'fullPrice',
        defaultMessage: 'Precio completo'
    },
    inclTax: {
        id: 'inclTax',
        defaultMessage: 'Incl. Impuesto:'
    },
    commissionAffection: {
        id: 'commissionAffection',
        defaultMessage: 'Afectación de Comisión'
    },
    createBusinessGroup: {
        id: 'createBusinessGroup',
        defaultMessage: 'Crear Grupo de Negocios'
    },
    businessGroups: {
        id: 'businessGroups',
        defaultMessage: 'Grupos de negocio'
    },
    createBusinessOffer: {
        id: 'createBusinessOffer',
        defaultMessage: 'Crear Oferta de Negocio'
    },
    sharedAllowance: {
        id: 'sharedAllowance',
        defaultMessage: 'Permiso Compartido'
    },
    configure: {
        id: 'configure',
        defaultMessage: 'Configurar'
    },
    noSharedAllowance: {
        id: 'noSharedAllowance',
        defaultMessage: 'No agregado de permiso compartido.'
    },
    plan: {
        id: 'plan',
        defaultMessage: 'Plan'
    },
    configureServices: {
        id: 'configureServices',
        defaultMessage: 'Configurar servicios'
    },
    subscriptions: {
        id: 'subscriptions',
        defaultMessage: 'Subscripctiones'
    },
    total: {
        id: 'total',
        defaultMessage: 'Total'
    },
    addOns: {
        id: 'addOns',
        defaultMessage: 'Agregados'
    },
    deviceUpper: {
        id: 'deviceUpper',
        defaultMessage: 'Dispositivo'
    },
    deviceLower: {
        id: 'deviceLower',
        defaultMessage: 'dispositivo'
    },
    installment: {
        id: 'installment',
        defaultMessage: 'Instalación'
    },
    statusPendingCreditClass: {
        id: 'statusPendingCreditClass',
        defaultMessage: 'Your credit class is being processed'
    },
    statusCreditClassReject: {
        id: 'statusCreditClassReject',
        defaultMessage: 'Your credit class was rejacted, to proceed please cancel agremeent'
    },
    statusPendingPolicyCheck: {
        id: 'statusPendingPolicyCheck',
        defaultMessage: 'Your credit policy is being processed'
    },
    statusPolicyCheckApproved: {
        id: 'statusPolicyCheckApproved',
        defaultMessage: 'Your credit class was approved! you can now view deposits and' +
        ' down payments in the Agreement Overview. To proceed to payment please' +
        ' Generate Contract'
    },
    statusPolicyCheckRejected: {
        id: 'statusPolicyCheckRejected',
        defaultMessage: 'Your credit policy was rejacted, to proceed please cancel agremeent'
    },
    statusPendingforPayment: {
        id: 'statusPendingforPayment',
        defaultMessage: 'Slip Number: '
    },
    statusPaymentCompleted: {
        id: 'statusPaymentCompleted',
        defaultMessage: 'status Payment Completed'
    },
    statusPendingforShipment: {
        id: 'statusPendingforShipment',
        defaultMessage: 'Your shipment is on the way'
    },
    statusShipmentCompleted: {
        id: 'statusShipmentCompleted',
        defaultMessage: 'Congratulations! You have all your devices, soon they will be all up and runing'
    },
    statusCompleted: {
        id: 'statusCompleted',
        defaultMessage: 'Congratulations! The process has come to an end'
    },
    statusCancelled: {
        id: 'statusCancelled',
        defaultMessage: 'This agreement was cancelled'
    },
    addSharedAllowance: {
        id: 'addSharedAllowance',
        defaultMessage: 'Agregados'
    },
    inheritedItem: {
        id: 'inheritedItem',
        defaultMessage: 'This item is inherited from existing sales agreement'
    },
    delete: {
        id: 'delete',
        defaultMessage: 'Borrar'
    },
    rejected: {
        id: 'rejected',
        defaultMessage: 'Rechazado'
    },
    rejectionReason: {
        id: 'rejectionReason',
        defaultMessage: 'Chequeo de Crédito fué rechazado por exeso de deuda ó balance '
    },
    creditResults: {
        id: 'creditResults',
        defaultMessage: 'Resultado de Evaluación de Crédito'
    },
    cancelAgreement: {
        id: 'cancelAgreement',
        defaultMessage: 'Cancelar Acuerdo'
    },
    manageDocuments: {
        id: 'manageDocuments',
        defaultMessage: 'Administrar documentos'
    },
    showMore: {
        id: 'showMore',
        defaultMessage: 'mostrar más'
    },
    showLess: {
        id: 'showLess',
        defaultMessage: 'Muestra menos'
    },
    serviceDeposit: {
        id: 'serviceDeposit',
        defaultMessage: 'depósito de servicio'
    },
    withoutTaxesMessage: {
        id: 'withoutTaxesMessage',
        defaultMessage: 'precios no incluyen impuestos'
    },
    downPayment: {
        id: 'downPayment',
        defaultMessage: 'Pago inicial a plazos'
    },
    DeviceDeposit: {
        id: 'DeviceDeposit',
        defaultMessage: 'Depósito del dispositivo'
    },
    immediatePayment: {
        id: 'immediatePayment',
        defaultMessage: 'Pago inmediato'
    },
    monthlyPayment: {
        id: 'monthlyPayment',
        defaultMessage: 'Mensualidad'
    },
    DBTFR: {
        id: 'DBTFR',
        defaultMessage: 'Debt and Forms required'
    },
    DEBT: {
        id: 'DEBT',
        defaultMessage: 'Deuda Encontrada'
    },
    FRAUD: {
        id: 'FRAUD',
        defaultMessage: 'Fraude Encontrado'
    },
    HOMON: {
        id: 'HOMON',
        defaultMessage: 'Homónimo Encontrado'
    },
    FORMS: {
        id: 'FORMS',
        defaultMessage: 'Formularios, Documentos Requeridos'
    },
    ICINP: {
        id: 'ICINP',
        defaultMessage: 'Ingreso Incompleto'
    },
    AGE: {
        id: 'AGE',
        defaultMessage: 'Calificación de edad no se encuentra'
    },
    CRDEC: {
        id: 'CRDEC',
        defaultMessage: 'Decosión de Crédito esta complete'
    },
    CCARD: {
        id: 'CCARD',
        defaultMessage: 'Tarjeta de Crédito Inválida'
    },
    ERROR: {
        id: 'ERROR',
        defaultMessage: 'Error'
    },
    CBERR: {
        id: 'CBERR',
        defaultMessage: 'Error de Oficina'
    },
    DPORD: {
        id: 'DPORD',
        defaultMessage: 'Órdenes Pendientes Duplicadas'
    },
    CPROC: {
        id: 'CPROC',
        defaultMessage: 'Aplicación de crédito pendiente Proceso'
    },
    CBALT: {
        id: 'CBALT',
        defaultMessage: 'Alerta de Oficina'
    },
    CBCNT: {
        id: 'CBCNT',
        defaultMessage: 'Cliente denegado a proveer Consentimiento de Oficina'
    },
    DEFAULT: {
        id: 'DEFAULT',
        defaultMessage: 'error sucedido'
    }
});
