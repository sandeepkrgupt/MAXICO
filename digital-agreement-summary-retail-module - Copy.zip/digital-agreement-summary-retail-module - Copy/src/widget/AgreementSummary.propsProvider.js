import {Utils} from 'digital-sdk';


class PropsProvider {
    constructor(context) {
        this.context = context;
    }
    getComponentProps(props) {
        const {config, actions} = props;
        return {
            intl: props.intl,
            widgetName: config.defaultName,
            totalAgreementSummaryPriceData: props.totalAgreementSummaryPriceData,
            totalAgreementSummaryGroupsData: props.totalAgreementSummaryGroupsData,
            formatPrice: Utils.formatPrice,
            formatPercentage: Utils.formatPercentage,
            goToSharedAllowance: actions.goToSharedAllowance,
            goToSelectPlan: actions.goToSelectPlan,
            goToConfigureBOT: actions.goToConfigureBOT,
            goToSetBusinessGroup: actions.goToSetBusinessGroup,
            removeBOT: actions.removeBOT,
            showModal: props.showModal,
            hidePopUp: actions.hidePopUp,
            cancleAgreement: actions.cancleAgreement,
            manageDocumentsConf: actions.getManageDocumentsConfig(),
            creditStatus: props.creditStatus,
            getSalesAgreementStatus: actions.getSalesAgreementStatus()
        };
    }
}

export default PropsProvider;
