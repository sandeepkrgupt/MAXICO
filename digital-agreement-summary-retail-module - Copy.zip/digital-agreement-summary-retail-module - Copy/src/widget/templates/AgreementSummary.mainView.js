import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';
import TotalPrice from './components/AgreementSummary.totalPrice';
import BusinessGroupList from './components/AgreementSummary.businessGroupList';
import ModalPopUp from './components/AgreementSummary.ModalPopUp';


class AgreementSummaryMainView extends Component {

    constructor(props) {
        super(props);
        this.context = props;
    }
    render() {
        this.isLoaded = this.props.totalAgreementSummaryPriceData || this.props.totalAgreementSummaryGroupsData;
        return (
            <div id="salesAgreementSummary">
                { this.isLoaded && (
                    <div className="container">
                        <div className="content">
                            <h3 className="header-style"><FormattedMessage {...messages.agreementSummaryTitle} /></h3>
                            { this.props.totalAgreementSummaryPriceData && (
                                <TotalPrice
                                    totalAgreementSummaryPriceData={this.props.totalAgreementSummaryPriceData}
                                    {...this.props} />
                            )}
                            { this.props.totalAgreementSummaryGroupsData && (
                                <BusinessGroupList
                                    totalAgreementSummaryGroupsData={this.props.totalAgreementSummaryGroupsData}
                                    {...this.props} />
                            )}
                        </div>
                    </div>
                )}
                <ModalPopUp {...this.props} />
            </div>

        );
    }
}

export default AgreementSummaryMainView;
