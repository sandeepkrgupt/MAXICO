import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import {Modal, Button} from 'react-bootstrap';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';

class ModalPopUp extends Component {
    constructor(props) {
        super(props);
        this.handleClose = this.handleClose.bind(this);
        this.cancleAgreement = this.cancleAgreement.bind(this);
    }

    handleClose() {
        this.props.hidePopUp();
    }
    cancleAgreement() {
        this.props.cancleAgreement();
    }

    render() {
        const ModalHeader = Modal.Header;
        const ModalBody = Modal.Body;
        const ModalFooter = Modal.Footer;
        let creditStatus = this.props.creditStatus;
        const isStatusCodeInMeassages = messages.creditStatus;
        if (!isStatusCodeInMeassages) {
            creditStatus = 'DEFAULT';
        }

        return (
            <div id="ModalContainer">
                <Modal
                    show={this.props.showModal}
                    onHide={this.handleClose}
                    className="modal-content-style"
                    backdrop="static" >
                    <ModalHeader closeButton className="text-center">
                        <p className="modelHeaderFontCss"><FormattedMessage {...messages.creditResults} /></p>
                    </ModalHeader>
                    <ModalBody className="text-center">
                        <p className="modal-body-FontCss"><FormattedMessage {...messages.rejected} /></p>
                        <p className="modal-body-FontSize">
                            <FormattedMessage {...messages.rejectionReason} />
                            <FormattedMessage {...messages[creditStatus]} />
                        </p>
                    </ModalBody>
                    <ModalFooter className="ButtonCenter">
                        <Button className="model-button-style" onClick={this.cancleAgreement}>
                            <FormattedMessage {...messages.cancelAgreement} />
                        </Button>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

export default ModalPopUp;
