import React, {Component} from 'react';
import {FormattedMessage} from 'react-intl';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';

export default function ManageDocuments (
    manageDocumentsProps
) {
    /*
    ------------------------------- SUB COMPONENTS -------------------------------
    */

    return (
        <div>
            <form
                method="post"
                action={manageDocumentsProps.maxImageURL}
                target="_blank">
                <label hidden>
                    <input type="text" name="userId" value={manageDocumentsProps.userID} disabled hidden />
                    <input type="text" name="archiveID" value={manageDocumentsProps.archiveID} disabled hidden />
                    <input type="text" name="origin" value={manageDocumentsProps.origin} disabled hidden />
                    <input type="text" name="customerID" value={manageDocumentsProps.customerID} disabled hidden />
                    <input type="text" name="password" value={manageDocumentsProps.password} disabled hidden />
                    <input type="text" name="ip" value={manageDocumentsProps.ip} disabled hidden />
                </label>
                <input
                    className="btn btn-link btn-manage-document"
                    type="submit"
                    value={messages.manageDocuments.defaultMessage} />
            </form>
        </div>
    );
}
