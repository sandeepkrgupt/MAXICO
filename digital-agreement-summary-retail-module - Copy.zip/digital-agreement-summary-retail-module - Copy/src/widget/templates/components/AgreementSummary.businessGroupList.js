import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import CreateAgreementActions from 'digital-create-sales-agreement-retail-module/src/sdk/CreateSalesAgreement.actions';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';
import BusinessGroup from './AgreementSummary.businessGroup';


class BusinessGroupList extends Component {
    constructor(props) {
        super(props);
        this.state = {};
        this.sa_status = this.props.getSalesAgreementStatus;
        this.goToSetBusinessGroup = this.props.goToSetBusinessGroup;
    }

    fetchData(data) {
        if (data.businessGroups && data.businessGroups.length > 0) {
            this.isBusinessGroups = true;
            this.businessGroupsCount = data.businessGroups.length;
            this.businessGroups = data.businessGroups.map((groupItem) => {
                const newGroup = {
                    groupName: groupItem.groupName,
                    groupID: groupItem.groupID
                };

                if (groupItem.sharedAllowance) {
                    newGroup.isSharedAllowance = true;
                    if (groupItem.sharedAllowance.basePlan) {
                        newGroup.sharedAllowanceName = groupItem.sharedAllowance.basePlan.planName;
                        newGroup.sharedAllowancePrice = this.props.formatPrice(
                            groupItem.sharedAllowance.basePlan.planPriceDetails &&
                            groupItem.sharedAllowance.basePlan.planPriceDetails.recurringCharge.totalAmountWithTax
                            , 'monthly', true);
                        newGroup.sharedAllowanceBasePlan = true;
                        newGroup.sharedAllowanceOrderId = groupItem.sharedAllowance.orderID;
                    }
                    newGroup.isAddSharedAllowanceAllowed = groupItem.sharedAllowance.isAddAllowed;
                }

                if (groupItem.bots && groupItem.bots.length > 0) {
                    newGroup.isBots = true;
                    newGroup.bots = groupItem.bots.map((botItem) => {
                        const newBot = {};
                        if (botItem.plan) {
                            newBot.planName = botItem.plan.planName;
                            newBot.orderActionID = botItem.plan.orderActionID;
                            newBot.orderID = botItem.plan.orderID;
                            newBot.planPrice = this.props.formatPrice(botItem.plan.price, 'monthly', true);
                            newBot.planSubscriptionsNo = botItem.plan.subscriptionsNo;
                            newBot.planTotalSubscriptionsPrice = this.props.formatPrice(
                                botItem.plan.totalSubscriptionsPrice, null, true);

                            if (botItem.plan.addOns) {
                                newBot.isAddOns = true;
                                newBot.addOnsPrice = this.props.formatPrice(botItem.plan.addOns.price, 'monthly', true);
                                newBot.addOnsTotalSubscriptionsPrice = this.props.formatPrice(
                                    botItem.plan.addOns.totalSubscriptionsPrice, 'monthly', true);

                                if (botItem.plan.addOns.addOnsList && botItem.plan.addOns.addOnsList.length > 0) {
                                    newBot.isAddOnsList = true;
                                    newBot.addOnsList = botItem.plan.addOns.addOnsList;
                                }
                            }
                        }

                        if (botItem.device) {
                            newBot.deviceName = botItem.device.deviceName;
                            newBot.deviceFullPrice = this.props.formatPrice(
                                botItem.device.fullPrice, null, true);
                            newBot.deviceTotalSubscriptionsPrice = this.props.formatPrice(
                                botItem.device.totalSubscriptionsPrice, null, true);

                            if (botItem.device.installments) {
                                newBot.isDeviceInstallments = true;
                                newBot.deviceInstallmentsCount = botItem.device.installments.count;
                                newBot.deviceInstallmentsPrice = this.props.formatPrice(
                                    botItem.device.installments.price, null, true);
                            }
                        }

                        return newBot;
                    });
                }

                return newGroup;
            });
        }
    }

    render() {
        this.fetchData(this.props.totalAgreementSummaryGroupsData);

        return (
            <div id="businessGroupList">
                <div id="groupsContainer" className="groups-total-section">
                    {this.sa_status === 'Configured' &&
                    <button
                        className="btn grayBtn"
                        id="goToSetBusinessGroupButton"
                        onClick={() => this.goToSetBusinessGroup()}>
                        <FormattedMessage {...messages.createBusinessGroup} />
                    </button>}
                    <div className="sub-count">{this.businessGroupsCount}</div>
                    <div className="sub-body"><FormattedMessage {...messages.businessGroups} /></div>
                </div>
                <div className="single-stroke" />
                { this.isBusinessGroups && this.businessGroups.map((groupItem) => {
                    return (
                        <BusinessGroup key={groupItem.groupID} groupItem={groupItem} {...this.props} />
                    );
                })}
            </div>
        );
    }
}

export default BusinessGroupList;
