import React, {Component} from 'react';
import {FormattedMessage} from 'react-intl';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';
import ManageDocuments from 'digital-agreement-summary-retail-module/src/widget/templates/components/AgreementSummary.ManageDocuments';

class TotalPrice extends Component {
    constructor(props) {
        super(props);
        this.state = {};
        this.state.isExpandTaxBtn = false;
        this.state.showMore = false;
    }

    fetchData(data) {
        this.businessGroups = data.businessGroups;
        this.agreementName = data.agreementName;
        this.totalMonthlyWithTax = data.totalMonthlyWithTax;
        this.totalMonthlyWithoutTax = data.totalMonthlyWithoutTax;
        this.totalImmediateWithTax = data.totalImmediateWithTax;
        this.totalImmediateWithoutTax = data.totalImmediateWithoutTax;
        this.commissionAffectation = this.props.formatPercentage(data.commissionAffectation);
        this.SA_Status = data.salesAgreementStatus;
        if (this.SA_Status && this.SA_Status.additionalInfo && this.SA_Status.additionalInfo.policyItem) {
            this.serviceDeposit =
                this.props.formatPrice(this.SA_Status.additionalInfo.policyItem.serviceDeposit, null, true);
            this.downPayment = this.props.formatPrice(this.SA_Status.additionalInfo.policyItem.downPayment, null, true);
            this.equipmentDeposit =
                this.props.formatPrice(this.SA_Status.additionalInfo.policyItem.equipmentDeposit, null, true);
        }
        this.subscriptionsNo = data.subscriptionsNo;
        if (data.totalAgreementPrice) {
            if (data.totalAgreementPrice.services) {
                this.servicePrice = this.props.formatPrice(data.totalAgreementPrice.services.price, 'monthly', true);
                this.freeMonths = data.totalAgreementPrice.services.freeMonths;
            }
            if (data.totalAgreementPrice.devices) {
                if (data.totalAgreementPrice.devices.installments &&
                    data.totalAgreementPrice.devices.installments.length > 0) {
                    this.isDeviceInstallments = true;
                    this.deviceInstallmentsCount =
                        data.totalAgreementPrice.devices.installments.count;
                    this.deviceInstallmentsPrice =
                        data.totalAgreementPrice.devices.installments.price;
                } else {
                    this.deviceFullPrice =
                        this.props.formatPrice(data.totalAgreementPrice.devices.fullPrice, null, true);
                }
            }
            if (data.totalAgreementPrice.immediatePayment) {
                this.immediateDevicesFullPrice = this.props.formatPrice(
                    data.totalAgreementPrice.immediatePayment.devicesFullPrice, null, true);
                this.immediateInstallmentPayment = this.props.formatPrice(
                    data.totalAgreementPrice.immediatePayment.installmentPayment, null, true);
                this.immediateServiceDeposit = this.props.formatPrice(
                    data.totalAgreementPrice.immediatePayment.serviceDeposit, null, true);
            }
            if (data.totalAgreementPrice.includeTax) {
                if (data.totalAgreementPrice.includeTax.services) {
                    this.taxServicesPrice = this.props.formatPrice(
                        data.totalAgreementPrice.includeTax.services.price, 'monthly', true);
                }
                if (data.totalAgreementPrice.includeTax.devices) {
                    if (data.totalAgreementPrice.includeTax.devices.installments &&
                        data.totalAgreementPrice.includeTax.devices.installments.length > 0) {
                        this.isTaxDeviceInstallments = true;
                        this.taxInstallmentsCount = data.totalAgreementPrice.includeTax.devices.installments.count;
                        this.taxInstallmentsPrice = this.props.formatPrice(
                            data.totalAgreementPrice.includeTax.devices.installments.price, 'monthly', true);
                    } else {
                        this.taxTotalPrice = this.props.formatPrice(
                            data.totalAgreementPrice.includeTax.devices.fullPrice, null, true);
                    }
                }
            }
        }
        this.messageStatusDescription = '';
        if (this.SA_Status) {
            this.statusID = `status${this.SA_Status.code}`;
        }
    }

    expandTaxClick() {
        this.setState({isExpandTaxBtn: !this.state.isExpandTaxBtn});
    }
    showMoreLessClick() {
        this.setState({showMore: !this.state.showMore});
    }

    render() {
        this.fetchData(this.props.totalAgreementSummaryPriceData);
        return (
            <div id="totalPrice">
                <b>Agreement Summary Total Price</b>
                {this.SA_Status && this.SA_Status.code &&
                (this.SA_Status.code !== 'Initiated' && this.SA_Status.code !== 'Configured') ? (
                    <div className={`clearfix statusArea ${this.SA_Status.code}`}>
                        <div className="col-md-offset-1 col-md-3 status">
                            {this.SA_Status.decode}
                        </div>
                        <div className="col-md-8 statusMessage">
                            <FormattedMessage {...messages[this.statusID]} />
                            {/* {this.SA_Status.additionalInfo.rejectInformationList &&
                            this.SA_Status.additionalInfo.rejectInformationList.map((list) => {
                                return (
                                    <div>{list.message}</div>);
                            })}
                            {this.SA_Status.additionalInfo.paySlipNumber ?
                                (<span>
                                    {this.SA_Status.additionalInfo.paySlipNumber}
                                </span>)
                                : ('')
                            } */}
                        </div>
                    </div>
                    ) : ('')}
                <div id="totalPriceContainer">
                    <div className="clearfix">
                        <div className="col-md-5">AGREEMENT OVERVIEW <b> {this.agreementName} </b></div>
                        <span id="taxToggle" className="side-header-btn" onClick={() => this.expandTaxClick()}>
                            {this.state.isExpandTaxBtn ?
                                <FormattedMessage {...messages.hideTax} /> :
                                <FormattedMessage {...messages.showTax} />}
                        </span>
                    </div>
                    <div className="clearfix topSummary">
                        <div className="col-md-4">
                            {this.props.totalAgreementSummaryGroupsData &&
                            this.props.totalAgreementSummaryGroupsData.businessGroups ?
                                (<div>
                                    <FormattedMessage {...messages.businessGroups} />
                                    ({this.props.totalAgreementSummaryGroupsData.businessGroups.length})
                            </div>) : ('')}
                            <div>
                                <FormattedMessage {...messages.totalSubscriptions} /> ({this.subscriptionsNo})
                            </div>
                            <ManageDocuments {...this.props.manageDocumentsConf} />
                        </div>
                        <div className="col-md-4">
                            <div><FormattedMessage {...messages.monthlyPayment} /></div>
                            <div>
                                {this.state.isExpandTaxBtn ? (this.totalMonthlyWithTax) :
                                    (this.totalMonthlyWithoutTax) }
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div><FormattedMessage {...messages.immediatePayment} /></div>
                            <div>
                                {this.state.isExpandTaxBtn ?
                                    (this.totalImmediateWithTax) : (this.totalImmediateWithoutTax)}
                            </div>
                        </div>
                        <div className="clearfix">
                            <div className="col-md-push-5 col-md-7">
                                {!this.state.isExpandTaxBtn &&
                                <div>*<FormattedMessage {...messages.withoutTaxesMessage} /></div>}
                            </div>
                        </div>
                    </div>
                    <div className="text-center" onClick={() => this.showMoreLessClick()}>
                        {this.state.showMore ? <FormattedMessage {...messages.showLess} /> :
                        <FormattedMessage {...messages.showMore} />}
                    </div>
                    {this.state.showMore &&
                    <div>

                        <div className="servicesArea">
                            <div className="clearfix subTitles">
                                <div className="col-md-4">
                                    <FormattedMessage {...messages.services} />
                                </div>
                            </div>
                            <div className="clearfix">
                                <div className="col-md-4">Service plan</div>
                                <div className="col-md-4">
                                    {this.state.isExpandTaxBtn ? (this.taxServicesPrice) :
                                        (this.servicePrice)}
                                </div>
                                <div className="col-md-4">---</div>
                            </div>
                            {this.SA_Status && this.SA_Status.additionalInfo.policyItem ?
                                (<div className="clearfix">
                                    <div className="col-md-4">
                                        <FormattedMessage {...messages.serviceDeposit} />
                                    </div>
                                    <div className="col-md-4">---</div>
                                    <div className="col-md-4">
                                        {this.serviceDeposit}
                                    </div>
                                </div>
                                ) : ('')}
                        </div>
                        <div className="deviceArea">
                            <div className="clearfix subTitles">
                                <div className="col-md-4">
                                    Devices
                                </div>
                                <div className="col-md-4" />
                                <div className="col-md-4" />
                            </div>
                            {/* <div className="row">
                                <div className="col-md-4">
                                    24 Installments
                                </div>
                                <div className="col-md-4">
                                    $33,600.00/mo
                                </div>
                                <div className="col-md-4">
                                    ------
                                </div>
                            </div> */}
                            <div className="clearfix">
                                <div className="col-md-4">
                                    <FormattedMessage {...messages.fullPrice} />
                                </div>
                                <div className="col-md-4">
                                    ---
                                </div>
                                <div className="col-md-4">
                                    {this.state.isExpandTaxBtn ? (this.taxTotalPrice) : (this.deviceFullPrice)}
                                </div>
                            </div>
                            {this.downPayment ?
                                (<div className="clearfix">
                                    <div className="col-md-4">
                                        <FormattedMessage {...messages.downPayment} />
                                    </div>
                                    <div className="col-md-4">
                                        ---
                                    </div>
                                    <div className="col-md-4">
                                        {this.downPayment}
                                    </div>
                                </div>) : ('')}
                            {this.equipmentDeposit ?
                                (<div className="clearfix">
                                    <div className="col-md-4">
                                        <FormattedMessage {...messages.DeviceDeposit} />
                                    </div>
                                    <div className="col-md-4">
                                        ---
                                    </div>
                                    <div className="col-md-4">
                                        {this.equipmentDeposit}
                                    </div>
                                </div>) : ('')}
                        </div>

                    </div>
                    }
                </div>


                { this.commissionAffectation && (
                    <div id="commissionAffectation" className="hightlight-label">
                        <div className="sub-label"><FormattedMessage {...messages.commissionAffection} /></div>
                        <div className="sub-body">{this.commissionAffectation}</div>
                    </div>
                )}
            </div>
        );
    }
}

export default TotalPrice;
