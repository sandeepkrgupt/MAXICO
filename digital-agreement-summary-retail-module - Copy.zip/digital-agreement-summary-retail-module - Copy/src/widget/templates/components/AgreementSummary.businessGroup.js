import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';
import BotItem from './AgreementSummary.botItem';

class BusinessGroup extends Component {
    constructor(props) {
        super(props);
        this.state = {};
        this.state.isExpandEditMenu = false;
        this.goToSharedAllowance = this.props.goToSharedAllowance;
        this.goToSelectPlan = this.props.goToSelectPlan;
        this.removeBOT = this.props.removeBOT;
        this.goToConfigureBOT = this.props.goToConfigureBOT;
        this.sa_status = this.props.getSalesAgreementStatus;
    }

    getExistingAllowedSharedAllowanceDiv() {
        return (
            <div className="existingAllowedSharedAllowance">
                <div className="header"><FormattedMessage {...messages.total} /></div>
                <div className="innerText clearfix">
                    <div className="planName">{this.businessGroup.sharedAllowanceName}</div>
                    <div className="price">{this.businessGroup.sharedAllowancePrice}</div>
                    {this.sa_status === 'Configured' &&
                    <i className="fas fa-ellipsis-v" onClick={() => this.expandEditMenu()}>
                        <div className={`editPopup ${this.state.isExpandEditMenu ? 'show' : ''}`} >
                            <div>
                                <i className="fas fa-cog" />
                                <FormattedMessage {...messages.configure} />
                            </div>
                            <div onClick={() => this.removeBOT({
                                orderID: this.businessGroup.sharedAllowanceOrderId
                            })}>
                                <i className="fas fa-trash-alt" />
                                <FormattedMessage {...messages.delete} />
                            </div>
                        </div>
                    </i>}
                </div>
            </div>
        );
    }

    getDisabledSharedAllowanceDiv() {
        return (
            <div className="addSharedAllowance clearfix">
                <i
                    className="fas fa-plus"
                    onClick={() =>
                        this.goToSharedAllowance({groupName: this.businessGroup.groupName})}
                />
                <div className="AddSharedAllowanceText">
                    <FormattedMessage {...messages.addSharedAllowance} />
                </div>
            </div>
        );
    }

    getAddSharedAllowanceDiv() {
        return (
            <div className="disabledSharedAllowance">
                <div className="innerLabel">{this.businessGroup.sharedAllowanceName}</div>
                <i className="fas fa-info-circle" />
                <div className="innerSmallLabel">
                    <FormattedMessage {...messages.inheritedItem} />
                </div>
            </div>
        );
    }

    getNotAvailableSharedAllowanceDiv() {
        return (
            <div className="notAvailableSharedAllowance clearfix">
                <i className="fas fa-info-circle" />
                <div className="notAvailableSharedAllowanceText">
                    <FormattedMessage {...messages.noSharedAllowance} />
                </div>
            </div>
        );
    }

    getRelevantDivForSharedAllowance() {
        if (this.businessGroup.isAddSharedAllowanceAllowed) {
            if (this.businessGroup.sharedAllowanceBasePlan) {
                return this.getExistingAllowedSharedAllowanceDiv();
            }
            return this.getDisabledSharedAllowanceDiv();
        }
        if (this.businessGroup.sharedAllowanceBasePlan) {
            return this.getAddSharedAllowanceDiv();
        }
        return this.getNotAvailableSharedAllowanceDiv();
    }

    fetchData(data) {
        this.businessGroup = data.groupItem;
    }

    expandEditMenu() {
        this.setState({isExpandEditMenu: !this.state.isExpandEditMenu});
    }

    render() {
        this.fetchData(this.props);
        return (
            <div id={`businessGroup_${this.businessGroup.groupID}`} className="businessGroup">
                <b>Business Group</b>
                <div className="topArea clearfix">
                    <div className="col-sm-3">
                        <h2>{this.businessGroup.groupName}</h2>
                    </div>
                    {this.sa_status === 'Configured' &&
                    <div>
                        <button
                            type="button"
                            className="btn grayBtn"
                            onClick={() => this.goToSelectPlan({
                                groupName: this.businessGroup.groupName,
                                groupID: this.businessGroup.groupID
                            })}>
                            <FormattedMessage {...messages.createBusinessOffer} />
                        </button>
                    </div>}
                </div>

                <div id={`sharedAllowanceArea_${this.businessGroup.groupName}`} className="sharedAllowanceArea">
                    <div className="subTitle"><FormattedMessage {...messages.sharedAllowance} /></div>
                    <div className="sharedAllowanceContainer">
                        {this.getRelevantDivForSharedAllowance()}
                    </div>
                </div>

                { this.businessGroup.isBots && this.businessGroup.bots.map((botItem) => {
                    return (
                        <BotItem
                            key={botItem.orderActionID}
                            botItem={botItem}
                            removeBOT={this.removeBOT}
                            goToConfigureBOT={this.goToConfigureBOT}
                            status={this.sa_status}
                        />
                    );
                })}
            </div>
        );
    }
}

export default BusinessGroup;
