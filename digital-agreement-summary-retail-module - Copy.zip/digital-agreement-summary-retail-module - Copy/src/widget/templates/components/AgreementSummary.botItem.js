import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import messages from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.i18n';

class BotItem extends Component {
    constructor(props) {
        super(props);
        this.state = {};
        this.state.isToggleCollapse = true;
        this.removeBOT = this.props.removeBOT;
        this.goToConfigureBOT = this.props.goToConfigureBOT;
        this.sa_status = this.props.status;
    }

    toggleCollapse () {
        this.setState({isToggleCollapse: !this.state.isToggleCollapse});
    }

    fetchData(data) {
        this.bot = data.botItem;
    }

    render() {
        this.fetchData(this.props);
        return (
            <div id={`bot_${this.bot.orderActionID}`} className="panel-group bot">
                <b>BotItem</b>
                {this.sa_status === 'Configured' &&
                <div className="section-header clearfix">
                    <a onClick={() => this.toggleCollapse()}>
                        <div className={this.state.isToggleCollapse ?
                            'fas fa-angle-down' :
                            'fas fa-angle-up'} />
                        <div className="subtitle"><FormattedMessage {...messages.plan} /></div>
                    </a>
                    <i
                        className="fas fa-trash-alt"
                        onClick={() => this.removeBOT({orderID: this.bot.orderID})} />
                    <div
                        className="btn grayBtn"
                        onClick={() => this.goToConfigureBOT({orderActionID: this.bot.orderActionID})}>
                        <FormattedMessage {...messages.configureServices} /></div>
                </div>}

                <div className={!this.state.isToggleCollapse ? 'hidden' : ''}>
                    <div className="panel-collapse">
                        <div className="row">
                            <div className="totalNumber">{this.bot.planName}</div>
                            <div className="col-md-3">{this.bot.planPrice}</div>
                            <div>
                                <div className="subNumber">{this.bot.planSubscriptionsNo}</div>
                                <div className="subLabel"><FormattedMessage {...messages.subscriptions} /></div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-3 smallLabelTotal">
                                <FormattedMessage {...messages.total} /> {this.bot.planTotalSubscriptionsPrice}
                            </div>
                        </div>

                        { this.bot.isAddOns &&
                            <div id={`addOns_${this.bot.orderActionID}`} className="panel-add-ons">
                                <div className="section-header textLabel">
                                    <FormattedMessage {...messages.addOns} />
                                </div>
                            </div>
                        }
                        {
                            this.bot.isAddOnsList && this.bot.addOnsList.map(() => {
                                return (
                                    <div />
                                );
                            })
                        }

                        <div id={`panelDevice_${this.bot.orderActionID}`} className="panel-devices">
                            <div className="section-header textLabel">
                                <FormattedMessage {...messages.deviceUpper} />
                            </div>
                            <div className="row">
                                <div className="innerLabel">{this.bot.deviceName}</div>
                                <div className="col-width">{this.bot.deviceFullPrice}</div>
                                <div className="col-md-2 mediumLabel">
                                    /<FormattedMessage {...messages.deviceLower} />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-width smallLabelTitle">
                                    <FormattedMessage {...messages.total} />
                                </div>
                                <div className="col-md-4 smallLabelValue">{this.bot.deviceTotalSubscriptionsPrice}</div>
                            </div>

                            { this.bot.isDeviceInstallments ?
                                (
                                    <div className="row rowHight">
                                        <div className="col-width smallLabelTitle">
                                            <FormattedMessage {...messages.installment} />
                                        </div>
                                        <div className="col-md-4 smallLabelValue">
                                            {this.bot.deviceInstallmentsCount} X {this.bot.deviceInstallmentsPrice}
                                        </div>
                                    </div>
                                ) : (
                                    <div className="row rowHight">
                                        <div className="smallLabelTitle italic float">
                                            <FormattedMessage {...messages.fullPrice} />
                                        </div>
                                    </div>
                                )
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default BotItem;
