import Component from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.component';
import Decorator from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.decorator';

export default Decorator(Component);
