const MANAGE_DOCUMENT_CONFIG = {
    ip: '10.19.131.254',
    origin: '23',
    userID: 'asmsa1',
    password: 'asmsa1',
    customerID: '123456',
    archiveID: '789',
    maxImageURL: 'http://135.208.61.10:14001/RepositoryATT/'
};

const TEST = '';
export {
    MANAGE_DOCUMENT_CONFIG,
    TEST
};
