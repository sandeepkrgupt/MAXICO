import registerTopic from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.topicRegistration';

registerTopic();
