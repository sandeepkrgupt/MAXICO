import SDK from 'digital-sdk';

const config = {
    name: 'agreement-summary',
    level: SDK.ActionsLevels.ORDER_LEVEL
};

export default config;
