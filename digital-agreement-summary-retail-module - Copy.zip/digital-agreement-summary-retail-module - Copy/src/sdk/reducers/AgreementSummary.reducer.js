import {SUCCESS_SUFFIX, REQUEST_SUFFIX, FAILURE_SUFFIX} from 'digital-sdk/lib/actions/types/const';
import SDK from 'digital-sdk';

import ActionTypes from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.actionTypes';
import SDKConfig from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.sdk.config';

const initialState = {};

const reducer = (state = initialState, action) => {
    const {type, payload = {}} = action;
    let newState;

    switch (type) {
    case ActionTypes.SET_AGREEMENT_SUMMARY_INPUT_PARAMETERS:
    case ActionTypes.UPDATE_SALES_AGREEMENT_SUMMARY_DATA:
    case ActionTypes.UPDATE_ADD_SHARED_ALLOWANCE_DATA:
    case ActionTypes.GO_TO_SELECT_PLAN_SCREEN:
    case ActionTypes.GO_TO_SET_BUSINESS_GROUP:
    case ActionTypes.CANCEL_ORDER:
    case ActionTypes.CANCEL_ORDER_STATUS:
    case ActionTypes.UPDATE_CONFIGURE_SELECTED_BOT:
    case ActionTypes.GO_TO_CONFIGURE_PLAN:
    case ActionTypes.SET_MODAL_SHOW:
        newState = {
            ...state,
            ...payload
        };
        break;
    case ActionTypes.SET_CREDIT_STATUS:
        newState = {
            ...state,
            ...payload
        };
        break;
    case `${ActionTypes.CANCEL_ORDER}${REQUEST_SUFFIX}`:
        newState = {
            ...state,
            ...payload,
            cancelOrderInProgress: true
        };
        break;
    case `${ActionTypes.CANCEL_ORDER}${SUCCESS_SUFFIX}`:
    case `${ActionTypes.CANCEL_ORDER}${FAILURE_SUFFIX}`:
        newState = {
            ...state,
            ...payload,
            cancelOrderInProgress: false
        };
        break;
    default:
        newState = state;
        break;
    }
    return newState;
};

const registrationFunc = () => {
    const {level, name} = SDKConfig;
    SDK.registerLevelReducer(level, name, reducer);
};

export {
    reducer as default,
    registrationFunc as registerReducer
};
