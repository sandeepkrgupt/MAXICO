import SDK from 'digital-sdk';
import __ from 'lodash';
import actionsConfig from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.actions.config';
import errorConfig from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.errors';
import SDKConfig from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.sdk.config';
import ActionTypes from 'digital-agreement-summary-retail-module/src/sdk/AgreementSummary.actionTypes';
import {registerReducer} from 'digital-agreement-summary-retail-module/src/sdk/reducers/AgreementSummary.reducer';
import CreateSalesAgreement from 'digital-create-sales-agreement-retail-module/lib/sdk/CreateSalesAgreement.actions';
import LoginActions from 'digital-login-module/src/sdk/Login.actions';
import DashboardActions from 'digital-dashboard-retail-module/src/sdk/Dashboard.actions';
import SetBusinessGroup from 'digital-set-business-group-retail-module/src/sdk/SetBusinessGroup.actions';
import {MANAGE_DOCUMENT_CONFIG} from 'digital-agreement-summary-retail-module/src/widget/AgreementSummary.config';

registerReducer();

const CommerceService = new SDK.DigitalServicesImpl.DigitalCommerceService();

export default class extends SDK.ActionClass {
    constructor(connectParams, store) {
        super(connectParams, store, SDKConfig, actionsConfig, errorConfig);
    }

    setActions() {
        super.setActions();
        this.createSalesAgreementAction = new CreateSalesAgreement(
            {contextId: this.connectParams.contextId}, this.store);
        this.SetBusinessGroupAction = new SetBusinessGroup(
            {contextId: this.connectParams.contextId}, this.store);

        this.loginActions = new LoginActions({}, this.store);
        this.dashboardActions = new DashboardActions({}, this.store);
    }

    getInitialData() {
        const initData = {
            totalAgreementSummaryGroupsData: {},
            totalAgreementSummaryPriceData: {},
            cancelOrderStatus: {},
            cancelOrderInProgress: false
        };
        return initData;
    }

    getModalData() {
        const ModalData = {showModal: false};
        return ModalData;
    }

    getManageDocumentsConfig() {
        // ToDo: Add service Request call when it's ready
        return MANAGE_DOCUMENT_CONFIG;
    }

    setInputParameters(data) {
        const initialData = this.getInitialData();
        const initModalData = this.getModalData();
        this.dispatchStoreAction(ActionTypes.SET_AGREEMENT_SUMMARY_INPUT_PARAMETERS,
            initialData);
        this.dispatchStoreAction(ActionTypes.SET_MODAL_SHOW,
            initModalData);
        const payload = this.getSalesAgreementPayload();

        // TODO- remove 'if' for inputs from modules store, only by payload
        if (!payload.salesAgreementOrderID) {
            // Only for testing purposes..
            // to avoid dependencies on prev modules, comment all lines and leave only first condition call
            this.fetchSalesAgreementSummary(
                {salesAgreementOrderID: '528', salesAgreementID: '100000589', userId: 'Asmsa1'});
        } else {
            this.fetchSalesAgreementSummary(payload);
        }
    }

    /* Services */

    getSalesAgreementPayload() {
        let salesAgreementOrderID = null;
        let salesAgreementID = null;
        let userId = null;

        const createSAOrderID = this.createSalesAgreementAction.getOrderId();
        const createSAID = this.createSalesAgreementAction.getAgreementId();

        if (createSAOrderID && createSAID) {
            salesAgreementOrderID = createSAOrderID;
            salesAgreementID = createSAID;
        }

        if (this.loginActions) {
            userId = this.loginActions.getUserId();
        }

        return {salesAgreementOrderID, salesAgreementID, userId};
    }

    getSalesAgreementSummary() {
        return this.getData();
    }

    getAddSharedAllowanceData() {
        return this.getData().addSharedAllowanceData;
    }

    getConfigureSelectedOrderActionId() {
        return this.getData().configureSelectedOrderActionId;
    }

    fetchSalesAgreementSummary(payload, config) {
        const serviceRequestPromise = this.serviceRequest(
            CommerceService,
            CommerceService.getSalesAgreementSummary,
            {
                data: payload,
                config
            },
            ActionTypes.RESERVE_SALES_AGREEMENT
        );

        serviceRequestPromise.then((result) => {
            if (result && result.data && result.data.salesAgreementSummary) {
                const inputData = result.data.salesAgreementSummary;
                const totalAgreementSummaryPriceData = this.fetchTotalAgreementSummaryPriceData(inputData);
                const totalAgreementSummaryGroupsData = this.fetchTotalAgreementSummaryGroupsData(inputData);
                const salesAgreementSummaryData = {totalAgreementSummaryPriceData, totalAgreementSummaryGroupsData};
                this.dispatchStoreAction(ActionTypes.UPDATE_SALES_AGREEMENT_SUMMARY_DATA,
                    salesAgreementSummaryData);
            }
        }).catch((err) => {
            console.log(err);
        });
    }

    fetchTotalAgreementSummaryPriceData(inputData) {
        const totalAgreementSummaryPriceData = {};
        totalAgreementSummaryPriceData.totalAgreementPrice = {};
        totalAgreementSummaryPriceData.totalMonthlyWithTax = inputData.totalMonthlyWithTax;
        totalAgreementSummaryPriceData.totalMonthlyWithoutTax = inputData.totalMonthlyWithoutTax;
        totalAgreementSummaryPriceData.totalImmediateWithTax = inputData.totalImmediateWithTax;
        totalAgreementSummaryPriceData.totalImmediateWithoutTax = inputData.totalImmediateWithoutTax;

        this.fetchTotAgrSumRecurringData(totalAgreementSummaryPriceData, inputData);
        this.fetchTotAgrSumImmediateData(totalAgreementSummaryPriceData, inputData);
        this.fetchTotAgrSumImmediatePayData(totalAgreementSummaryPriceData, inputData);
        totalAgreementSummaryPriceData.subscriptionsNo = inputData.totalQuantity;
        totalAgreementSummaryPriceData.commissionAffectation = inputData.commissionAffectation;
        totalAgreementSummaryPriceData.agreementName = inputData.agreementName;
        if (inputData.salesAgreementStatus) {
            totalAgreementSummaryPriceData.salesAgreementStatus = inputData.salesAgreementStatus;
        }

        return totalAgreementSummaryPriceData;
    }

    fetchTotAgrSumRecurringData(totalAgreementSummaryPriceData, inputData) {
        if (inputData.totalPriceDetails && inputData.totalPriceDetails.recurringCharge) {
            totalAgreementSummaryPriceData.totalAgreementPrice.services = {
                price: inputData.totalPriceDetails.recurringCharge.totalAmountWithoutTax,
                freeMonths: []
            };
            if (!totalAgreementSummaryPriceData.totalAgreementPrice.includeTax) {
                totalAgreementSummaryPriceData.totalAgreementPrice.includeTax = {};
            }
            totalAgreementSummaryPriceData.totalAgreementPrice.includeTax.services = {
                price: inputData.totalPriceDetails.recurringCharge.totalAmountWithTax
            };
        }
    }

    fetchTotAgrSumImmediateData(totalAgreementSummaryPriceData, inputData) {
        if (inputData.totalPriceDetails && inputData.totalPriceDetails.immediateCharge) {
            totalAgreementSummaryPriceData.totalAgreementPrice.devices = {
                // TODO- next iteration
                installments: {
                    count: null,
                    price: null
                },
                fullPrice: inputData.totalPriceDetails.immediateCharge.totalAmountWithoutTax
            };
            if (!totalAgreementSummaryPriceData.totalAgreementPrice.includeTax) {
                totalAgreementSummaryPriceData.totalAgreementPrice.includeTax = {};
            }
            totalAgreementSummaryPriceData.totalAgreementPrice.includeTax.devices = {
                installments: {
                    count: null,
                    price: null
                },
                fullPrice: inputData.totalPriceDetails.immediateCharge.totalAmountWithTax
            };
        }
    }

    fetchTotAgrSumImmediatePayData(totalAgreementSummaryPriceData, inputData) {
        // TODO- next iteration
        totalAgreementSummaryPriceData.totalAgreementPrice.immediatePayment = {
            devicesFullPrice: null,
            installmentPayment: null,
            serviceDeposit: null
        };
    }

    fetchTotalAgreementSummaryGroupsData(inputData) {
        const totalAgreementSummaryGroupsData = {};
        totalAgreementSummaryGroupsData.businessGroups = [];
        if (inputData.businessGroupDetails && inputData.businessGroupDetails.length > 0) {
            totalAgreementSummaryGroupsData.businessGroups = inputData.businessGroupDetails.map((groupItem) => {
                const newGroupItem = {
                    groupName: groupItem.groupName,
                    groupID: groupItem.groupID,
                    // TODO- next iteration
                    sharedAllowance: groupItem.sharedAllowance,
                    // sharedAllowance: {
                    //     planName: null,
                    //     price: null
                    // }
                };

                newGroupItem.bots = groupItem.boTemplate.map((botItem) => {
                    return this.fetchTotAgrSumBotsPlanData(botItem);
                });

                return newGroupItem;
            });
        }
        return totalAgreementSummaryGroupsData;
    }

    fetchTotAgrSumBotsPlanData(botItem) {
        const newBotItem = {};
        newBotItem.plan = {};
        if (botItem.basePlan) {
            newBotItem.plan.planName = botItem.basePlan.planName;
            if (botItem.basePlan.planPriceDetails && botItem.basePlan.planPriceDetails.recurringCharge) {
                newBotItem.plan.price = botItem.basePlan.planPriceDetails.recurringCharge.amoutWithoutTax;
                newBotItem.plan.totalSubscriptionsPrice =
                    botItem.basePlan.planPriceDetails.recurringCharge.totalAmountWithoutTax;
            }
        }
        newBotItem.plan.orderActionID = botItem.orderActionID;
        newBotItem.plan.orderID = botItem.orderID;
        newBotItem.plan.subscriptionsNo = botItem.quantity;

        // TODO- next iteration (use map)
        newBotItem.plan.addOns = null;
        // {
        //     // price: null,
        //     // totalSubscriptionsPrice: null,
        //     // addOnsList: []
        // };

        this.fetchTotAgrSumBotsDeviceData(newBotItem, botItem);

        return newBotItem;
    }
    hidePopUp() {
        this.dispatchStoreAction(ActionTypes.SET_MODAL_SHOW, {showModal: false});
        this.dispatchStoreAction(ActionTypes.GO_TO_DASHBOARD, {});
    }
    cancleAgreement() {
        this.dispatchStoreAction(ActionTypes.SET_MODAL_SHOW, {showModal: false});
        this.dispatchStoreAction(ActionTypes.GO_TO_DASHBOARD, {});
    }
    performCreditCheckSuccess(response) {
        this.dispatchStoreAction(
            ActionTypes.SET_CREDIT_STATUS, {creditStatus: response.data.responseCreditCheck.statusReason});
        if (Object.keys(response.data.responseCreditCheck).length !== 0) {
            if (response.data.responseCreditCheck.creditStatus !== 'RA') {
                const stateData = this.getData();
                const agreementName = stateData.totalAgreementSummaryPriceData.agreementName;
                this.dashboardActions.setSuccessMessage(`${agreementName} 
                    Fué exitosamente enviado a validación de crédito`);
                this.dispatchStoreAction(ActionTypes.GO_TO_DASHBOARD, {});
            } else {
                this.dispatchStoreAction(ActionTypes.SET_MODAL_SHOW, {showModal: true});
            }
        }
    }
    performCreditCheckFailure() {

    }
    fetchTotAgrSumBotsDeviceData(newBotItem, botItem) {
        newBotItem.device = {};

        // TODO -'device' convention instead of 'plan' in the params
        if (botItem.deviceDetails) {
            newBotItem.device.deviceName = botItem.deviceDetails.planName;
            if (botItem.deviceDetails.planPriceDetails &&
                botItem.deviceDetails.planPriceDetails.immediateCharge) {
                newBotItem.device.fullPrice =
                    botItem.deviceDetails.planPriceDetails.immediateCharge.amoutWithoutTax; // totalimmediateWithTax
                newBotItem.device.totalSubscriptionsPrice =
                    botItem.deviceDetails.planPriceDetails.immediateCharge.totalAmountWithoutTax;
                // totalimmediateWithoutTax
                // TODO- next iteration
                newBotItem.device.installments = null;
                // {
                //     count: null,
                //     price: null
                // };
            }
        }
    }

    goToConfigureBOT(data) {
        this.dispatchStoreAction(ActionTypes.UPDATE_CONFIGURE_SELECTED_BOT,
            {configureSelectedOrderActionId: data.orderActionID});

        this.dispatchStoreAction(ActionTypes.GO_TO_CONFIGURE_PLAN, {});
    }

    goToSharedAllowance(data) {
        const summaryData = this.getSalesAgreementSummary();
        const payloadData = this.getSalesAgreementPayload();
        const {businessGroups} = summaryData.totalAgreementSummaryGroupsData;
        const businessGroup = __.find(businessGroups, (bsGroup) => {
            return bsGroup.groupName === data.groupName;
        });

        const addSharedAllowanceData = {
            addSharedAllowanceData: {
                ...payloadData,
                agreementName: summaryData && summaryData.totalAgreementSummaryPriceData ?
                    summaryData.totalAgreementSummaryPriceData.agreementName : '',
                groupName: data.groupName,
                groupId: summaryData && summaryData.totalAgreementSummaryGroupsData ? businessGroup.groupID : ''
            }
        };

        this.dispatchStoreAction(ActionTypes.UPDATE_ADD_SHARED_ALLOWANCE_DATA,
            addSharedAllowanceData);

        this.dispatchStoreAction(ActionTypes.GO_TO_ADD_SHARED_ALLOWANCE, {});
    }

    getCreditCheckPayload() {
        const creditCheckData = this.getSalesAgreementPayload();
        const prepareCreditCheckJson = {
            salesAgreementOrderId: creditCheckData.salesAgreementOrderID,
            salesAgreementID: creditCheckData.salesAgreementID,
            userId: creditCheckData.userId
        };
        return prepareCreditCheckJson;
    }

    performCreditCheck() {
        const payload = this.getCreditCheckPayload();
        return new Promise((resolve, reject) => {
            const serviceRequestPromise = this.serviceRequest(
                CommerceService,
                CommerceService.performCreidtCheck,
                {payload}, ActionTypes.PERFORM_CREDIT_CHECK,
                this.performCreditCheckSuccess.bind(this),
                this.performCreditCheckFailure.bind(this)
            );
            serviceRequestPromise.then((res) => {
                resolve(res);
            }).catch((err) => {
                reject(err);
            });
        });
    }

    goToSelectPlan(data) {
        this.SetBusinessGroupAction.setBusinessGroup(data.groupName, data.groupID);
        this.dispatchStoreAction(ActionTypes.GO_TO_SELECT_PLAN_SCREEN,
            {groupName: data.groupName});
    }

    goToSetBusinessGroup() {
        this.dispatchStoreAction(ActionTypes.GO_TO_SET_BUSINESS_GROUP);
    }

    removeBOTRestCall({orderId, getSalesAgreementPayload}) {
        // TODO- remove 'if'. only for standlone testing
        if (!getSalesAgreementPayload.salesAgreementOrderID) {
            getSalesAgreementPayload.salesAgreementOrderID = '528';
            getSalesAgreementPayload.salesAgreementID = '100000589';
            getSalesAgreementPayload.userId = 'Asmsa1';
        }

        const data = {};

        return new Promise((resolve, reject) => {
            const cancelOrderInProgress = this.getData().cancelOrderInProgress;
            if (!cancelOrderInProgress) {
                const serviceRequestPromise = this.serviceRequest(
                    CommerceService,
                    CommerceService.cancelOrder,
                    {payload: {orderId, userId: getSalesAgreementPayload.userId}, data},
                    ActionTypes.CANCEL_ORDER
                );
                serviceRequestPromise.then((res) => {
                    resolve(res);
                    this.dispatchStoreAction(ActionTypes.CANCEL_ORDER_STATUS,
                        {cancelOrderStatus: res.data});

                    this.fetchSalesAgreementSummary(getSalesAgreementPayload);
                }).catch((err) => {
                    reject(err);
                    this.dispatchStoreAction(ActionTypes.CANCEL_ORDER_STATUS,
                        {cancelOrderStatus: err.data});
                });
            }
        });
    }

    removeBOT(data) {
        const getSalesAgreementPayload = this.getSalesAgreementPayload();
        this.removeBOTRestCall({orderId: data.orderID, getSalesAgreementPayload});
    }

    getSalesAgreementStatus() {
        return this.createSalesAgreementAction.getStatus();
    }

    getPublicActions() {
        return [
            'getSalesAgreementSummary',
            'goToSharedAllowance',
            'getAddSharedAllowanceData',
            'goToSelectPlan',
            'goToSetBusinessGroup',
            'removeBOT',
            'getConfigureSelectedOrderActionId',
            'goToConfigureBOT',
            'hidePopUp',
            'cancleAgreement',
            'getManageDocumentsConfig',
            'getSalesAgreementStatus'
        ];
    }

    onStateUpdate(/* data */) {
        // here is the place to respond to relevant state data changes and call relevant actions
        // data argument contains the module mapped state data
    }
}

