/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';
import { IntlProvider } from 'react-intl';
import {expect} from 'chai';
import {shallow, mount} from 'enzyme';
import { Utils } from 'digital-sdk';
import testingData from 'digital-mock-service-module/lib/digital/responses/commerce/test/salesAgreementSummaryResponse.json';
import TotalPrice from '../src/widget/templates/components/AgreementSummary.totalPrice';
import BusinessGroup from '../src/widget/templates/components/AgreementSummary.businessGroup';
import BusinessGroupList from '../src/widget/templates/components/AgreementSummary.businessGroupList';


const utilsTestProps = {
    formatPrice: Utils.formatPrice,
    formatPercentage: Utils.formatPercentage
};

export function tests() {

    describe('Total Price - Component Test', function() {
        let wrapper;
        beforeEach(function(){
            wrapper = mount(
                <IntlProvider locale="en">
                    <TotalPrice totalAgreementSummaryPriceData={testingData.totalAgreementSummaryPriceData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

        // it('Check Toggle Tax - True', function() {
        //     wrapper.find("#taxToggle").simulate("click");
        //     expect(wrapper.state().isExpandTaxBtn).to.be.true;
        // });

        it('Hide tax via state', function() {
            wrapper.setState({ isExpandTaxBtn: false });
            expect(wrapper.state().isExpandTaxBtn).to.be.false;
        });

        it("Comission Affection is 3%", function () {
            expect(wrapper.find("#commissionAffectation").children().find(".sub-body").text()).to.be.equal(testingData.totalAgreementSummaryPriceData.commissionAffectation + "%");
        });
    });

    describe('Business Group List- Component Test', function() {
        let wrapper;
        beforeEach(function(){
            wrapper = mount(
                <IntlProvider locale="en">
                    <BusinessGroupList totalAgreementSummaryGroupsData={testingData.totalAgreementSummaryGroupsData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

        it("Mapping list of Business Group", function () {
            expect(wrapper.find('.businessGroup')).to.have.length(testingData.totalAgreementSummaryGroupsData.businessGroups.length);
        });

        it("Mapping list of BOT`s", function () {
            const count = testingData.totalAgreementSummaryGroupsData.businessGroups.map((botItem) => {
                return (
                    botItem.bots.length
                );
            });
            const reducer = (accumulator, currentValue) => accumulator + currentValue;
            expect(wrapper.find('.panel-group')).to.have.length(count.reduce(reducer));
        });
    });

    describe('Business Group - Component Test', function() {
        let wrapper;
        beforeEach(function(){
            wrapper = mount(
                <IntlProvider locale="en">
                    <BusinessGroupList totalAgreementSummaryGroupsData={testingData.totalAgreementSummaryGroupsData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

        it("Marketing BOT should have pop up window", function () {
            expect(wrapper.find('.sharedAllowanceContainer').at(0).find('.fa-ellipsis-v'));
        });

        it("Management BOT should be disabled", function () {
            expect(wrapper.find('.sharedAllowanceContainer').at(1).find('.disabledSharedAllowance'));
        });

        it("Finance BOT should have add shared allowance icon", function () {
            expect(wrapper.find('.sharedAllowanceContainer').at(2).find('.fa-plus'));
        });

        it("Advertising BOT should have not available shared allowance", function () {
            expect(wrapper.find('.sharedAllowanceContainer').at(2).find('.notAvailableSharedAllowance'));
        });

    });

}

export default tests();
