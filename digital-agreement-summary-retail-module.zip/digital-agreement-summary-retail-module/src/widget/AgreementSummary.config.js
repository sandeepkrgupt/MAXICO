const MANAGE_DOCUMENT_CONFIG = {
    MAX_IMAGE_IP: '10.19.131.254',
    MAX_IMAGE_ORIGIN: '23',
    MAX_IMAGE_USER_ID: 'asmsa1',
    MAX_IMAGE_USER_PASSWORD: 'asmsa1',
    customerID: '123456',
    archiveID: '789',
    MAX_IMAGE_URL: 'http://135.208.61.10:14001/RepositoryATT/'
};


export default {
    MANAGE_DOCUMENT_CONFIG
};
