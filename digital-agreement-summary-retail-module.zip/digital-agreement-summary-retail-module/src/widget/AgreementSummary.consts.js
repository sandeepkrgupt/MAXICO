const EDITABLE_STATUS = 'Draft';
const DELIVERY_METHOD = 'storePickUp';
const PAYMENT_BOX_SIMULATOR_URL = '/PaymentBoxFlowSimulator.jsp';
const DIGITAL_JSP_RETURN_URL = '/PaymentBoxFlowResult.jsp';

export {
    EDITABLE_STATUS,
    DELIVERY_METHOD,
    PAYMENT_BOX_SIMULATOR_URL,
    DIGITAL_JSP_RETURN_URL
};
