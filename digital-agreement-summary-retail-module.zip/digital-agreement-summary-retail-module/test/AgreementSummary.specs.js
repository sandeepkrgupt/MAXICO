/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';
import {IntlProvider} from 'react-intl';
import {expect} from 'chai';
import {mount} from 'enzyme';
import {Utils} from 'digital-sdk';
import testingData from 'digital-mock-service-module/lib/digital/responses/commerce/test/salesAgreementSummaryResponse.json';
import TotalPrice from '../src/widget/templates/components/AgreementSummary.totalPrice';
import BusinessGroupList from '../src/widget/templates/components/AgreementSummary.businessGroupList';


const utilsTestProps = {
    formatPrice: Utils.formatPrice,
    formatPercentage: Utils.formatPercentage
};

export function tests () {

    describe('Total Price - Component Test', function () {
        let wrapper;
        beforeEach(function () {
            wrapper = mount(
                <IntlProvider locale="en">
                    <TotalPrice totalAgreementSummaryPriceData={testingData.totalAgreementSummaryPriceData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

        it('Hide tax via state', function () {
            wrapper.setState({isExpandTaxBtn: false});
            expect(wrapper.state().isExpandTaxBtn).to.be.false;
        });

    });

    describe('Business Group List- Component Test', function () {

        beforeEach(function () {
            mount(
                <IntlProvider locale="en">
                    <BusinessGroupList totalAgreementSummaryGroupsData={testingData.totalAgreementSummaryGroupsData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

    });

    describe('Business Group - Component Test', function () {
        beforeEach(function () {
            mount(
                <IntlProvider locale="en">
                    <BusinessGroupList totalAgreementSummaryGroupsData={testingData.totalAgreementSummaryGroupsData} {...utilsTestProps} />
                </IntlProvider>
            );
        });

    });

}

export default tests();
